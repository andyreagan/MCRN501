function z=truncation_f(x,a)

z = x.^2+sqrt(a+x.^2);

end